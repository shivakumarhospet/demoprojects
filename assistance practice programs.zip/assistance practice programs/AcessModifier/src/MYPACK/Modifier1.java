package MYPACK;

public class Modifier1 {

   public int hours=3;
   public int minutes=47;
}
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
	
