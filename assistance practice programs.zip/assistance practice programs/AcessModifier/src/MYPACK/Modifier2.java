package MYPACK;

public class Modifier2 {

	public static void main(String[] args) {
	
		
Modifier1 a= new Modifier1();
System.out.println(a.hours);
System.out.println(a.minutes);


	}

}
