package PACK;

import MYPACK.Modifier1;

public class Modifier3 {

	public static void main(String[] args) {
		  
		
		Modifier1 a= new Modifier1();
		System.out.println(a.hours);
		System.out.println(a.minutes);

	}

}
